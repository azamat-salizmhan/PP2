"""
clock.py - Clock logic for Mickey's Clock Application
Handles time retrieval and angle calculations for clock hands.
"""

import datetime
import math


class Clock:
    """Handles time logic and angle calculations for clock hands."""

    def get_time(self):
        """Return current system time as a datetime object."""
        return datetime.datetime.now()

    def get_minute_angle(self, now=None):
        """
        Calculate the rotation angle for the minute hand.
        0 degrees = pointing up (12 o'clock), clockwise is positive.
        Returns angle in degrees.
        """
        if now is None:
            now = self.get_time()
        minutes = now.minute
        seconds = now.second
        # Smooth movement: include seconds for gradual sweep
        total_seconds = minutes * 60 + seconds
        angle = (total_seconds / 3600) * 360  # 3600 seconds in 60 minutes
        return angle

    def get_second_angle(self, now=None):
        """
        Calculate the rotation angle for the second hand.
        0 degrees = pointing up (12 o'clock), clockwise is positive.
        Returns angle in degrees.
        """
        if now is None:
            now = self.get_time()
        seconds = now.second
        angle = (seconds / 60) * 360
        return angle

    def get_hour_angle(self, now=None):
        """
        Calculate the rotation angle for the hour hand (optional, 12-hour).
        """
        if now is None:
            now = self.get_time()
        hours = now.hour % 12
        minutes = now.minute
        total_minutes = hours * 60 + minutes
        angle = (total_minutes / 720) * 360  # 720 minutes in 12 hours
        return angle
