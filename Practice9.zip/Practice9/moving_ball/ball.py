"""
ball.py - Ball class for the Moving Ball Game.
Handles position, movement, and boundary checking.
"""


class Ball:
    """
    Represents the red ball on screen.

    Attributes:
        x, y    : centre position (pixels)
        radius  : ball radius in pixels
        step    : pixels moved per key press
        color   : RGB tuple
    """

    RADIUS  = 25          # radius = 25  →  diameter = 50
    STEP    = 20          # pixels per key press
    COLOR   = (220, 30, 30)

    def __init__(self, screen_width, screen_height):
        self.screen_w = screen_width
        self.screen_h = screen_height
        self.radius   = self.RADIUS
        self.step     = self.STEP
        self.color    = self.COLOR
        # Start in the centre
        self.x = screen_width  // 2
        self.y = screen_height // 2

    # ── Movement ──────────────────────────────────────────────────────────────

    def move_up(self):
        """Move up by one step; ignore if it would go off-screen."""
        new_y = self.y - self.step
        if new_y - self.radius >= 0:
            self.y = new_y

    def move_down(self):
        """Move down by one step; ignore if it would go off-screen."""
        new_y = self.y + self.step
        if new_y + self.radius <= self.screen_h:
            self.y = new_y

    def move_left(self):
        """Move left by one step; ignore if it would go off-screen."""
        new_x = self.x - self.step
        if new_x - self.radius >= 0:
            self.x = new_x

    def move_right(self):
        """Move right by one step; ignore if it would go off-screen."""
        new_x = self.x + self.step
        if new_x + self.radius <= self.screen_w:
            self.x = new_x

    # ── Accessors ─────────────────────────────────────────────────────────────

    def get_pos(self):
        """Return (x, y) centre position."""
        return (self.x, self.y)
